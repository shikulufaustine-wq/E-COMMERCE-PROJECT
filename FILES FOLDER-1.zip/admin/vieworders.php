 <?php
include "../db.php";

$result=mysqli_query($conn,"
SELECT orders.id,users.name,orders.total,orders.status
FROM orders
JOIN users ON orders.user_id=users.id
");
?>
<link rel="stylesheet" href="../style.css">
<div class="container">
<h2>All Orders</h2>
<?php while($row=mysqli_fetch_assoc($result)){ ?>
<p>
Order ID: <?php echo $row['id']; ?> |
Customer: <?php echo $row['name']; ?> |
Total: <?php echo $row['total']; ?> Tsh |
Status: <?php echo $row['status']; ?>
</p>
<?php } ?>
</div>