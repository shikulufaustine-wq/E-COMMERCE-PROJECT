 <?php
include "../db.php";

if(isset($_POST['add'])){
$name=$_POST['name'];
$price=$_POST['price'];
$desc=$_POST['description'];

mysqli_query($conn,"INSERT INTO products(name,price,description)
VALUES('$name','$price','$desc')");

echo "Product Added!";
}
?>
<link rel="stylesheet" href="../style.css">
<div class="container">
<h2>Add Product</h2>
<form method="POST">
<input type="text" name="name" required placeholder="Product Name">
<input type="number" name="price" required placeholder="Price">
<input type="text" name="description" required placeholder="Description">
<button name="add">Add Product</button>
</form>
</div>