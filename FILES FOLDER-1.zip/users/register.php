 <?php
include "db.php";

if(isset($_POST['register'])){
$name=$_POST['name'];
$email=$_POST['email'];
$password=md5($_POST['password']);

mysqli_query($conn,"INSERT INTO users(name,email,password)
VALUES('$name','$email','$password')");

header("Location: login.php");
}
?>
<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Register</h2>
<form method="POST">
<input type="text" name="name" required placeholder="Name">
<input type="email" name="email" required placeholder="Email">
<input type="password" name="password" required placeholder="Password">
<button name="register">Register</button>
</form>
</div>