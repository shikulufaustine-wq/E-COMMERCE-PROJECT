 <?php
include "db.php";

$total=0;
foreach($_SESSION['cart'] as $id){
$result=mysqli_query($conn,"SELECT price FROM products WHERE id=$id");
$row=mysqli_fetch_assoc($result);
$total+=$row['price'];
}

$user=$_SESSION['user'];
$userData=mysqli_fetch_assoc(mysqli_query($conn,"SELECT id FROM users WHERE email='$user'"));
$user_id=$userData['id'];

mysqli_query($conn,"INSERT INTO orders(user_id,total,status)
VALUES('$user_id','$total','Pending')");

$order_id=mysqli_insert_id($conn);

$_SESSION['order_id']=$order_id;

header("Location: payment.php");
?>