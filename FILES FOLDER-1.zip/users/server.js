 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>e/commerce</title>
<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #e8f5e9;
        color: #1b5e20;
    }
    header { background-color: #2e7d32; color: white; padding: 20px; text-align: center; }
    h1 { margin: 0; font-size: 36px; }
    nav { display: flex; justify-content: center; background-color: #43a047; }
    nav button { background: none; border: none; padding: 15px 25px; font-size: 16px; cursor: pointer; color: white; }
    nav button:hover { background-color: #388e3c; }
    section { display: none; padding: 40px 20px; max-width: 800px; margin: auto; }
    section.active { display: block; }
    form { background-color: #c8e6c9; padding: 20px; border-radius: 8px; max-width: 400px; margin: auto; }
    input[type=text], input[type=password], input[type=email] { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #2e7d32; border-radius: 4px; }
    button.submit-btn { background-color: #43a047; color: white; padding: 12px 20px; border: none; border-radius: 5px; cursor: pointer; width: 100%; font-size: 16px; }
    button.submit-btn:hover { background-color: #388e3c; }
    .products { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; }
    .product { background-color: #c8e6c9; padding: 15px; border-radius: 8px; text-align: center; }
    .product button { margin-top: 10px; background-color: #2e7d32; color: white; border: none; padding: 10px; cursor: pointer; border-radius: 5px; }
    .product button:hover { background-color: #1b5e20; }
    .cart-item { background-color: #a5d6a7; padding: 10px; border-radius: 6px; margin-bottom: 10px; display: flex; justify-content: space-between; }
    footer { text-align: center; padding: 20px; margin-top: 40px; font-size: 14px; color: #555; }
</style>
</head>
<body>

<header>
    <h1>Welcome to e/commerce</h1>
</header>

<nav>
    <button onclick="showSection('login')">Login</button>
    <button onclick="showSection('register')">Register</button>
    <button onclick="showSection('catalog')">Products</button>
    <button onclick="showSection('cart')">Cart</button>
</nav>

<!-- Login -->
<section id="login" class="active">
    <h2>Login</h2>
    <form id="loginForm">
        <input type="email" id="loginEmail" placeholder="Email" required>
        <input type="password" id="loginPassword" placeholder="Password" required>
        <button type="submit" class="submit-btn">Login</button>
    </form>
</section>

<!-- Register -->
<section id="register">
    <h2>Register</h2>
    <form id="registerForm">
        <input type="text" id="regName" placeholder="Full Name" required>
        <input type="email" id="regEmail" placeholder="Email" required>
        <input type="password" id="regPassword" placeholder="Password" required>
        <button type="submit" class="submit-btn">Register</button>
    </form>
</section>

<!-- Product Catalog -->
<section id="catalog">
    <h2>Our Products</h2>
    <div class="products"></div>
</section>

<!-- Shopping Cart -->
<section id="cart">
    <h2>Your Cart</h2>
    <div id="cart-items"></div>
    <h3 id="cart-total">Total: $0</h3>
</section>

<footer>
    &copy; 2026 e/commerce — All rights reserved
</footer>

<script>
let currentUser = null;

function showSection(id) {
    document.querySelectorAll('section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

// ---------- Register ----------
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const res = await fetch('http://localhost:3000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    alert(data.message || data.error);
    if(data.userId) showSection('login');
});

// ---------- Login ----------
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const res = await fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if(data.userId) {
        currentUser = { id: data.userId, name: data.name };
        alert('Login successful! Welcome ' + data.name);
        loadProducts();
        showSection('catalog');
        loadCart();
    } else {
        alert(data.error);
    }
});

// ---------- Load Products ----------
async function loadProducts() {
    const res = await fetch('http://localhost:3000/api/products');
    const products = await res.json();
    const catalogDiv = document.querySelector('.products');
    catalogDiv.innerHTML = '';
    products.forEach(p => {
        const div = document.createElement('div');
        div.className = 'product';
        div.innerHTML = `<h3>${p.name}</h3><p>$${p.price}</p>
                         <button onclick="addToCart(${p.id}, '${p.name}', ${p.price})">Add to Cart</button>`;
        catalogDiv.appendChild(div);
    });
}

// ---------- Cart ----------
async function addToCart(productId, name, price) {
    if(!currentUser) return alert('Please login first!');
    const res = await fetch('http://localhost:3000/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, productId, quantity: 1 })
    });
    const data = await res.json();
    alert(data.message || data.error);
    loadCart();
}

async function loadCart() {
    if(!currentUser) return;
    const res = await fetch(`http://localhost:3000/api/cart/${currentUser.id}`);
    const items = await res.json();
    const cartDiv = document.getElementById('cart-items');
    cartDiv.innerHTML = '';
    let total = 0;
    items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'cart-item';
        div.textContent = `${item.name} x${item.quantity} - $${item.price * item.quantity}`;
        cartDiv.appendChild(div);
        total += item.price * item.quantity;
    });
    document.getElementById('cart-total').textContent = 'Total: $' + total;
}
</script>

</body>
</html>