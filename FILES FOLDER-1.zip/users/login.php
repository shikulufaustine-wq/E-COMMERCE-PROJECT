 <?php
include "db.php";

if(isset($_POST['login'])){
$email=$_POST['email'];
$password=md5($_POST['password']);

$result=mysqli_query($conn,"SELECT * FROM users WHERE email='$email' AND password='$password'");

if(mysqli_num_rows($result)>0){
$_SESSION['user']=$email;
header("Location: index.php");
}else{
echo "Invalid Login";
}
}
?>
<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Login</h2>
<form method="POST">
<input type="email" name="email" required>
<input type="password" name="password" required>
<button name="login">Login</button>
</form>
</div>