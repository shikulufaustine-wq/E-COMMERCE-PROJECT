 <?php
include "db.php";

if(isset($_POST['pay'])){
$order_id=$_SESSION['order_id'];
$method=$_POST['method'];

mysqli_query($conn,"INSERT INTO payments(order_id,payment_method,payment_status)
VALUES('$order_id','$method','Paid')");

mysqli_query($conn,"UPDATE orders SET status='Paid' WHERE id='$order_id'");

unset($_SESSION['cart']);

echo "<h2>Payment Successful!</h2>";
}
?>
<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Select Payment Method</h2>
<form method="POST">
<select name="method">
<option value="Cash">Cash</option>
<option value="Mobile Money">Mobile Money</option>
<option value="Bank Transfer">Bank Transfer</option>
</select>
<button name="pay">Pay Now</button>
</form>
</div>