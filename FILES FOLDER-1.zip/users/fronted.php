 <?php
include "db.php";
if(!isset($_SESSION['user'])) header("Location: login.php");
?>
<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Products</h2>
<a href="cart.php">Cart</a> |
<a href="logout.php">Logout</a>

<?php
$result=mysqli_query($conn,"SELECT * FROM products");
while($row=mysqli_fetch_assoc($result)){
?>
<div class="product">
<h3><?php echo $row['name']; ?></h3>
<p><?php echo $row['description']; ?></p>
<p><b><?php echo $row['price']; ?> Tsh</b></p>
<form method="POST" action="add_to_cart.php">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
<button name="add">Add to Cart</button>
</form>
</div>
<?php } ?>
</div>