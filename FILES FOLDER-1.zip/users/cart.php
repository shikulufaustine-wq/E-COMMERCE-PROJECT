 <?php
include "db.php";
?>
<link rel="stylesheet" href="style.css">
<div class="container">
<h2>Your Cart</h2>
<?php
$total=0;
if(isset($_SESSION['cart'])){
foreach($_SESSION['cart'] as $id){
$result=mysqli_query($conn,"SELECT * FROM products WHERE id=$id");
$row=mysqli_fetch_assoc($result);
echo "<p>".$row['name']." - ".$row['price']." Tsh</p>";
$total+=$row['price'];
}
}
echo "<h3>Total: ".$total." Tsh</h3>";
?>
<a href="checkout.php"><button>Proceed to Checkout</button></a>
</div>