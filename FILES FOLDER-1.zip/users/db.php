<?php
$conn = mysqli_connect("localhost","root","","ecommerce_system");

if(!$conn){
die("Connection Failed");
}

session_start();
?>